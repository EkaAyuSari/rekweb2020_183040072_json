<?php 
$mahasiswa = [
    "nama" => "Sandika Galih",
    "nrp" => "043040023",
    "email" => "sandikagalih@unpas.ac.id"
];

$data = json_encode($mahasiswa);
enco $data;

?>
