<?php 

$mahasiswa = [
    
    "nama" => "Sandika Galih",
    "nrp" => "043040023",
    "email" => "sandikagalih@unpas.ac.id"
],
    "nama" => "Erik Doank",
    "nrp" => "023040001",
    "email" => "erik@gmail.com"
];

$data = json_encode($mahasiswa);
enco $data;

?>